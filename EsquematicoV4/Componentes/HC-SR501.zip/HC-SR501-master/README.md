# HC-SR501
HC-SR501 Kicad Footrint and 3D file
